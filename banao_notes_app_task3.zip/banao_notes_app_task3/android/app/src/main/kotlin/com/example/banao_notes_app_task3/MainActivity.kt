package com.example.banao_notes_app_task3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
