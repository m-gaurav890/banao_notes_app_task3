import 'package:flutter/material.dart';
Color bgColor=const Color(0xFF212227);
Color cardColor=const Color(0xFF2D2E33);
Color black=const Color(0xFF000000);
Color white=const Color(0xFFFFFFFF);